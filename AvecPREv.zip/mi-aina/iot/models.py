from django.conf import settings
from django.db import models

class Device(models.Model):
    STATUT_CHOICES = [('CONNECTÉ','Connecté'),('EN PRÊT','En prêt'),('HORS LIGNE','Hors ligne')]
    code = models.CharField(max_length=6, unique=True)                 # '#14'
    nom  = models.CharField(max_length=60)                             # Boîtier ESP32 #14
    statut = models.CharField(max_length=12, choices=STATUT_CHOICES, default='HORS LIGNE')
    batterie = models.PositiveSmallIntegerField(default=100)           # %
    signal   = models.PositiveSmallIntegerField(default=0)             # 0-3 barres
    firmware = models.CharField(max_length=12, default='v2.3.1')
    csb      = models.ForeignKey('csb.CSB', null=True, on_delete=models.SET_NULL)
    assigne_a = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                                  on_delete=models.SET_NULL, related_name='devices')
    created_at = models.DateTimeField(auto_now_add=True)

class Measure(models.Model):
    device = models.ForeignKey(Device, on_delete=models.CASCADE, related_name='mesures')
    patient = models.ForeignKey('patients.Patient', null=True, blank=True, on_delete=models.SET_NULL)
    consultation = models.ForeignKey('consultations.Consultation', null=True, blank=True, on_delete=models.SET_NULL)
    # Some devices do not provide all three readings. Keep old measurements,
    # while allowing an infrared-temperature-only capture.
    spo2 = models.PositiveSmallIntegerField(null=True, blank=True)
    temperature = models.DecimalField(max_digits=4, decimal_places=1, null=True, blank=True)
    bpm = models.PositiveSmallIntegerField(null=True, blank=True)
    synchronise = models.BooleanField(default=False)      # False = file locale (hors-ligne)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name_plural = 'Mesures'
